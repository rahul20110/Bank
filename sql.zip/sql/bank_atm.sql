-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: bank
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `atm`
--

DROP TABLE IF EXISTS `atm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `atm` (
  `ATM_ID` int NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` varchar(50) NOT NULL,
  `Pincode` int NOT NULL,
  `Cash` int NOT NULL,
  PRIMARY KEY (`ATM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atm`
--

LOCK TABLES `atm` WRITE;
/*!40000 ALTER TABLE `atm` DISABLE KEYS */;
INSERT INTO `atm` VALUES (109964207,'Noida','Haryana',375072,637369),(110106860,'Gandhinagar','Dadra and Nagar Haveli',180607,121529),(119966095,'Gandhinagar','Odisha',596589,327084),(156237458,'Guwahati','Tripura',173406,618425),(189984717,'Faridabad','Goa',251605,209809),(194639502,'Gangtok','Punjab',469890,970860),(196824122,'Jaipur','Meghalaya',380885,538368),(214858819,'Vadodara','Jammu and Kashmir',316978,743919),(242732812,'Gandhinagar','Goa',543018,326463),(252484736,'Ratlam','Madhya Pradesh',363255,699586),(267270453,'Alwar','Odisha',338490,555295),(284696197,'Noida','Daman and Diu',151862,619724),(308589008,'Bikaner','Jammu and Kashmir',101696,315220),(310437022,'Udaipur','Tripura',569955,890852),(324188598,'Patna','Manipur',186596,927104),(331261715,'Indore','Mizoram',372653,758652),(342456126,'Gangtok','Tamil Nadu',481425,289305),(349421455,'Srinagar','Kerala',326448,103662),(356112018,'Lucknow','Lakshadweep',349440,42090),(374383304,'Pondicherry','Tamil Nadu',583388,175077),(386502450,'Panaji','Tamil Nadu',546535,800215),(389912110,'Ratlam','West Bengal',378511,740219),(405190205,'Kochi','Mizoram',360420,783558),(410872399,'Ajmer','Chhattisgarh',270500,881585),(410945229,'Ajmer','Nagaland',222629,555253),(412841755,'Ranchi','Maharashtra',297365,77406),(456751491,'Thiruvananthapuram','Telangana',206469,561760),(467771709,'Darjeeling','Goa',286572,781553),(498973144,'Mumbai','Puducherry',170574,951985),(507981027,'Ahmedabad','Jharkhand',215800,795140),(512618251,'Jodhpur','Maharashtra',218190,313492),(544200950,'Vishakhapattanam','Jharkhand',549627,489936),(563197898,'Bikaner','Uttar Pradesh',533320,893166),(583355828,'Kota','Mizoram',383879,805626),(605233212,'Jamnagar','Telangana',134042,748045),(612229626,'Raipur','Bihar',458175,290416),(621805615,'Hisar','Goa',289268,940473),(625432177,'Kolkata','Lakshadweep',160866,125570),(635549134,'Vadodara','Andaman and Nicobar Islands',381967,787092),(668957110,'Gandhinagar','Nagaland',181606,550802),(708345309,'Pondicherry','Bihar',219923,779806),(739667166,'Pondicherry','Mizoram',109497,289560),(753454916,'Alwar','Kerala',364848,911054),(755084712,'Hisar','Haryana',194634,687246),(769442134,'Ajmer','Jharkhand',112080,938100),(791788835,'Dehra Dun','Gujarat',480636,772329),(821315191,'Trichy','Chhattisgarh',587614,47432),(825958313,'Nagpur','West Bengal',435810,246666),(837335099,'Dehra Dun','Delhi',329852,43362);
/*!40000 ALTER TABLE `atm` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-29 13:53:33
