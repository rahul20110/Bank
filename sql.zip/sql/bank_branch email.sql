-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: bank
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `branch email`
--

DROP TABLE IF EXISTS `branch email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch email` (
  `Branch_ID` int DEFAULT NULL,
  `Branch email` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch email`
--

LOCK TABLES `branch email` WRITE;
/*!40000 ALTER TABLE `branch email` DISABLE KEYS */;
INSERT INTO `branch email` VALUES (308680565,'smpeters@icloud.com'),(735481668,'dhrakar@yahoo.com'),(300807818,'drezet@sbcglobal.net'),(554152302,'mbalazin@verizon.net'),(854018808,'sonnen@live.com'),(877153575,'bonmots@comcast.net'),(485831677,'sthomas@yahoo.ca'),(67126578,'rgarcia@live.com'),(712408567,'bogjobber@me.com'),(601821144,'purvis@mac.com'),(270584284,'choset@hotmail.com'),(644081504,'jonas@yahoo.com'),(884663033,'tamas@att.net'),(113483553,'rupak@yahoo.com'),(641374433,'skippy@mac.com'),(7574237,'intlprog@comcast.net'),(546168822,'tangsh@hotmail.com'),(141875877,'frostman@msn.com'),(245281387,'howler@gmail.com'),(724557117,'dkeeler@hotmail.com'),(766601068,'yxing@hotmail.com'),(734582658,'nasarius@gmail.com'),(435562872,'solomon@aol.com'),(377053134,'smeier@gmail.com'),(827663756,'yumpy@sbcglobal.net'),(511022472,'mfburgo@gmail.com'),(216204666,'hauma@optonline.net'),(676227767,'miturria@sbcglobal.net'),(268026784,'ryanvm@me.com'),(32404373,'ninenine@outlook.com'),(17317202,'claesjac@verizon.net'),(331050117,'ramollin@aol.com'),(302756504,'overbom@aol.com'),(512828260,'yumpy@optonline.net'),(776368528,'ozawa@outlook.com'),(615526640,'fraser@outlook.com'),(654208657,'nasarius@mac.com'),(555276341,'tubajon@comcast.net'),(528182730,'sartak@comcast.net'),(832434504,'wonderkid@icloud.com'),(602256703,'gward@me.com'),(241857000,'nasarius@live.com'),(145110155,'jsbach@outlook.com'),(315667832,'sriha@sbcglobal.net'),(438711522,'jemarch@att.net'),(417267573,'fudrucker@icloud.com'),(83806381,'marioph@live.com'),(848654084,'adhere@aol.com'),(821760442,'euice@hotmail.com'),(18656254,'jcholewa@live.com'),(17317202,'matthijs@outlook.com'),(331050117,'bcevc@hotmail.com'),(302756504,'gregh@verizon.net'),(512828260,'pkplex@comcast.net'),(776368528,'mfleming@optonline.net'),(615526640,'bmorrow@comcast.net'),(145110155,'nelson@aol.com'),(315667832,'amaranth@aol.com'),(438711522,'frederic@live.com'),(89899899,'hermes@comcast.net');
/*!40000 ALTER TABLE `branch email` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-29 13:53:33
