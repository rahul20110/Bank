-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: bank
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `CustomerID` int NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Street` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` varchar(50) NOT NULL,
  `Pincode` int NOT NULL,
  `DOB` date NOT NULL,
  `User_ID` varchar(50) DEFAULT NULL,
  `Password` varchar(20) NOT NULL,
  PRIMARY KEY (`CustomerID`),
  UNIQUE KEY `User_ID` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (99999,'Rahul','Kumar','dfd','fddsf','erre',332001,'1951-09-06','dfdsfdsf','sdfdsf'),(43008270,'Ram','Lowten','Dayton','Sanok','Puducherry',106928,'2006-10-02','nlowten15','raVj4RRerA6'),(50394832,'Martainn','Zolini','Jenifer','Napanee Downtown','Arunachal Pradesh',302298,'1951-09-05','mzolinis','RRvVpHcP7bIz'),(78342298,'Windy','Kauscher','Maryland','Renhe','Uttar Pradesh',296926,'1951-04-25','wkauscherx','vDBEcMoDm5d'),(82351033,'Hollyanne','Piers','Kropf','Bernay','Uttarakhand',306796,'1984-09-04','hpiersv','9285Rd9m8'),(105007482,'See','Bulger','Maryland','Jawatiwa','Chhattisgarh',420459,'2003-11-19','sbulger5','BBbxVTawFltn'),(109329126,'Eleonore','Keeting','Bay','Jnkping','Tamil Nadu',570514,'1965-07-21','ekeeting1','GJkHzV9jPQmv'),(124312820,'Adelice','Goodbar','Dakota','Bulahblangaro','Tripura',189737,'1985-12-08','agoodbarn','5jz6rT97f'),(126449721,'Deeanne','Feragh','Anniversary','Shangtian','Bihar',531327,'1944-09-26','dferagh9','QgmqMuxz9Rxs'),(182330905,'Stevena','Spilstead','Vidon','Sailaitang','Goa',411981,'2016-12-20','sspilstead2','SZWqkJ'),(256432348,'Clevie','Joannic','Summer Ridge','Charat','Andhra Pradesh',278733,'1971-05-16','cjoannic7','CZD4yc'),(296205659,'Kore','Jaggers','Arapahoe','Urcos','Jharkhand',458509,'1951-10-17','kjaggersf','lvSf0CY5HfS'),(296560502,'Lilia','Esome','Fair Oaks','Eisen','Meghalaya',135173,'1983-04-27','lesome12','x1MIgCkU59W'),(297458145,'Eleonora','Grenville','Wayridge','Kaleybar','Telangana',502503,'2012-09-05','egrenville19','rSM6xPsYH'),(303601023,'Keefer','Gorger','Cascade','Lampang','Daman and Diu',233761,'1974-08-18','kgorgerd','uzHxobQNKvUX'),(306740510,'Ximenez','Lentsch','Columbus','Banjar Batanpoh','Madhya Pradesh',112015,'2002-09-17','xlentsch14','WmaAazaZqiqH'),(313638535,'Crysta','Rapi','Kennedy','Torss','Punjab',216713,'1996-02-20','crapih','FTWPeT'),(313654019,'Cheri','Slyman','Tennyson','Pemberton','Telangana',450658,'2017-05-10','cslymanz','iP7a6P'),(329075094,'Teodoor','Strathman','Harper','Baizhifang','Delhi',542003,'1987-03-24','tstrathmanq','i7bkgVL1mJb'),(340862630,'Bobbie','Bauldry','Everett','Peal','Puducherry',567363,'1975-06-01','bbauldry6','lsEB07'),(349039502,'sdfds','sfs','sdf','dfsd','sdfds',200302,'2003-03-25','sdfdsf','sdfds'),(354590595,'Chase','Dwerryhouse','Scofield','Jardn','Delhi',130521,'2021-12-26','cdwerryhouse0','ThWGAOsNl'),(380183004,'Nadine','Luckcock','Moulton','Montlimar','Himachal Pradesh',126065,'1952-08-07','nluckcock18','vR8tMuGg8ehl'),(382719363,'Hello','How','idk','idk','idk',110022,'1981-03-25','idk','idk'),(383376605,'Issiah','Prugel','Alpine','Xinhua','Delhi',573625,'2011-05-25','iprugelw','XifKYr144d8c'),(387380346,'Germain','Lound','Meadow Vale','Xiaozhi','Gujarat',138586,'1996-06-09','gloundr','tNBoptP'),(401321729,'Zachary','Stote','Melvin','Barisl','Tripura',583749,'1969-12-31','zstotec','dDYcFqE99g'),(429198326,'Leanora','Brood','Butterfield','Chuncheon','Odisha',181163,'2007-07-31','lbroodj','f5uP6o5Cb'),(438487393,'Frederik','Crump','Miller','Yasnogorsk','Goa',352819,'1941-09-17','fcrumpi','KxUTxSdjxs'),(505518687,'Burnaby','Giannini','Boyd','Coelho Neto','Jammu and Kashmir',505959,'1955-10-30','bgianninil','4ZCFML1kQEu'),(541980591,'Rodi','Briddock','4th','Illapel','Tripura',599849,'1968-04-28','rbriddock10','RKXeLtQEpT'),(568097353,'Murial','Brideaux','Lunder','Fengjiang','Meghalaya',473748,'1959-03-09','mbrideaux8','oWz6ZnYyb02z'),(571041341,'Kettie','Blanch','Macpherson','Citalahab','Uttar Pradesh',224776,'1941-12-01','kblanch1d','BRX8UoXJF9'),(613627569,'Gaby','Lovemore','Summit','Qin','Meghalaya',542120,'1958-07-23','glovemorek','AJg1QhcqsUFg'),(613814683,'Rozanna','Gooble','Pearson','Jinshanwei','Jharkhand',510808,'1950-07-06','rgooble1c','VXSTQ3zC7Gt'),(626771405,'Celeste','Silver','Roxbury','Yuanba','Uttarakhand',193669,'1996-05-31','csilver13','eGWEDs7wN'),(646591845,'Rosalie','Brymham','Moland','Pujijie','Odisha',237659,'2000-02-08','rbrymhamt','L4pDUs'),(658864353,'Winn','Weyman','Briar Crest','Hiroshima-shi','Mizoram',121868,'1947-08-29','wweyman11','VRZus2'),(663216313,'Juliana','Belderfield','Hintze','Karlstad','Odisha',177924,'2016-07-02','jbelderfield16','FqJ2LQuVCT'),(678864488,'Merola','Ivashnikov','Rutledge','Iwkowa','Odisha',334561,'1990-12-26','mivashnikov17','jbdiLXQf'),(692511833,'Yard','Evangelinos','Florence','Xialaba','Arunachal Pradesh',357580,'2015-03-17','yevangelinoso','9t6VBsW'),(721717683,'Michaella','Sanches','New Castle','Pancoran','Karnataka',326647,'2002-10-29','msanchesp','Q8KzVY6'),(722579690,'Charmine','Macey','Golf View','Pontinha','Rajasthan',425281,'1978-09-19','cmaceyg','NX7WwWVVRfBq'),(747865684,'Magdaia','Symms','Lakeland','Chicago','Nagaland',265567,'2000-12-13','msymmsy','lpWZR7c'),(820909636,'Waylon','Perigo','Anthes','Opatov','Nagaland',163739,'1955-10-07','wperigou','hgFCPM'),(829571699,'Lamont','Brazer','Lunder','Tomaevac','Arunachal Pradesh',535102,'2002-03-15','lbrazere','GSsBMsd'),(896733792,'Hans','Jeremaes','Utah','Konary','Tamil Nadu',389783,'1972-05-20','hjeremaes1a','4YqnKP'),(917381274,'Amalia','Cheshire','Village','Apeldoorn','Odisha',203251,'2000-12-31','acheshirea','Sf2bss'),(938460904,'Adolphe','Patron','Service','Acul du Nord','Puducherry',106012,'1982-01-11','apatron4','XLxK7LnQnBP'),(964356938,'Lishe','Wheaton','Memorial','Trollhttan','Mizoram',456328,'1971-05-28','lwheatonm','RfbFJWwnyhMg'),(975613985,'Bea','Lowater','Graedel','Jrflla','Delhi',160162,'2004-03-11','blowater1b','alH2ov'),(981184898,'Lamont','Zupo','Heath','Fanrong','Daman and Diu',309634,'1941-11-27','lzupob','4y8jrP'),(981353369,'Shela','Odney','Upham','Wewit','Telangana',206498,'1982-06-25','sodney3','9xyrtgPe');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `information` AFTER INSERT ON `customer` FOR EACH ROW begin
		if(DATE_FORMAT(FROM_DAYS(DATEDIFF(now(),New.DOB)), '%Y')+0 >0 and DATE_FORMAT(FROM_DAYS(DATEDIFF(now(),New.DOB)), '%Y')+0 <=20)
        then
        insert into teenager values(New.CustomerID,New.First_Name,New.Last_Name);
		elseif(DATE_FORMAT(FROM_DAYS(DATEDIFF(now(),New.DOB)), '%Y')+0 >20 and DATE_FORMAT(FROM_DAYS(DATEDIFF(now(),New.DOB)), '%Y')+0 <=59)
        then 
        insert into adult values(New.CustomerID,New.First_Name,New.Last_Name);
        else
        insert into senior values(New.CustomerID,New.First_Name,New.Last_Name);
        end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-29 13:53:31
