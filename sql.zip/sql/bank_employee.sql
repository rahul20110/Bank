-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: bank
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `Emp_ID` int NOT NULL,
  `User_ID` varchar(50) DEFAULT NULL,
  `Password` varchar(30) NOT NULL,
  `Emp_Name` varchar(90) NOT NULL,
  `Branch_ID` int NOT NULL,
  `DOJ` date NOT NULL,
  `Designation` varchar(90) NOT NULL,
  PRIMARY KEY (`Emp_ID`),
  KEY `Branch_ID` (`Branch_ID`),
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`Branch_ID`) REFERENCES `branch` (`Branch_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (11622670,'cletus26','lJJ3c0i','Dr Billy Bednar',712408567,'2019-09-26','Sales'),(16050586,'schmeler.josiane','0M7iAyTEdHab','Camylle Gutmann',877153575,'2020-01-27','Marketing'),(26767766,'ahmed.hammes','MmMHrVLIsBA','Prof Deonte Klein DDS',308680565,'2017-04-19','Marketing'),(36168784,'goodwin.anderson','DlTkYRI62','Ms Berniece Koss MD',735481668,'2017-06-12','Manager'),(65782842,'kling.neva','wY0bks0','Terrance Halvorson',67126578,'2018-06-07','Sales'),(122135264,'maxie.sporer','YmSxxzwq2gbc','Rosendo Lubowitz',735481668,'2019-01-28','Service'),(141757402,'mcglynn.dolores','pdOFgg','Irving Witting',67126578,'2017-11-13','Sales'),(155775135,'osvaldo.wintheiser','Jznyh8','Leone Dach II',554152302,'2019-11-13','Marketing'),(218177110,'grady.leopoldo','ox5WsW5ISou','Patrick Brown',854018808,'2018-11-01','Service'),(254485833,'eugene31','Kq4l60Eoadi','Dr Kendrick Dach PhD',877153575,'2018-08-05','Manager'),(301161224,'oconner.zaria','AVjmsYvgB','Hugh Renner DVM',485831677,'2020-11-07','Sales'),(342436455,'preston88','tHae3oHw','Lorenzo Mills',308680565,'2020-11-17','Sales'),(378781376,'conn.bettye','GByUp0','Colleen Cummerata PhD',854018808,'2018-03-13','Marketing'),(387221670,'america62','8Hi8U4kL1','Florencio Kuhic',554152302,'2017-08-26','Manager'),(442456526,'carolanne49','HeJaVAEHoRy','Laurie Kunze',485831677,'2019-04-02','Manager'),(453768652,'mdare','7sstya6PLXDI','Theresa Gerhold DVM',300807818,'2017-05-21','Manager'),(465065421,'ccartwright','NBdJsKvo','Casimir Klein',712408567,'2018-02-03','Manager'),(517173110,'sydnee.bernhard','XzDVxYQB3bp','Prof Dock Boyer III',735481668,'2019-07-24','Service'),(562501203,'abcde','zG9H1GQV','Zaria Garland',308680565,'2017-10-24','Manager'),(608056340,'rbalistreri','XEJirUgQL83','Prof Sherwood Walter Sr',67126578,'2019-03-20','Manager'),(608628780,'keebler.mark','tm14kYURr','Garland Kessler',554152302,'2017-02-04','Marketing'),(610834610,'treutel.margarette','xxl2dJ0','Jasmin Ledner',300807818,'2019-07-03','Sales'),(633688505,'demarcus.rice','wzcunM','Zaria Dietrich',854018808,'2020-02-14','Service'),(650520001,'durgan.chad','MCKgbtX','Larue Oberbrunner',712408567,'2018-04-18','Marketing'),(674808576,'ostroman','ZofTDszF8d','Naomi Gutmann',485831677,'2018-04-12','Marketing'),(700356785,'ellie80','LDU7N1bJhby','Tamia Nolan',300807818,'2018-01-03','Service'),(701331743,'boyer.polly','CKIohJX5Y','Ed Considine',485831677,'2020-11-12','Service'),(751457282,'vtoy','9I88knQrW','Mrs Glenda Emard PhD',877153575,'2018-06-03','Marketing'),(837147482,'teresa.fisher','cTlqZ3V','Mr Hazel Kessler MD',485831677,'2019-09-04','Marketing'),(883126588,'treutel.ron','Fr7RxUwRw4rL','Zola Aufderhar',854018808,'2021-02-21','Manager');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-29 13:53:32
