-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: bank
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `loan`
--

DROP TABLE IF EXISTS `loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loan` (
  `CustomerID` int NOT NULL,
  `Branch_ID` int NOT NULL,
  `Loan_ID` int NOT NULL AUTO_INCREMENT,
  `Loan_Type` varchar(30) NOT NULL,
  `Duration` smallint NOT NULL,
  `Amount_taken` int NOT NULL,
  `Rate` smallint NOT NULL,
  `Loan_status` varchar(30) DEFAULT NULL,
  `Amount_paid` int DEFAULT '0',
  `Amount_to_return` int DEFAULT NULL,
  PRIMARY KEY (`Loan_ID`),
  KEY `CustomerID` (`CustomerID`),
  KEY `Branch_ID` (`Branch_ID`),
  CONSTRAINT `loan_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customer` (`CustomerID`),
  CONSTRAINT `loan_ibfk_2` FOREIGN KEY (`Branch_ID`) REFERENCES `branch` (`Branch_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan`
--

LOCK TABLES `loan` WRITE;
/*!40000 ALTER TABLE `loan` DISABLE KEYS */;
INSERT INTO `loan` VALUES (721717683,308680565,26,'home',20,500000,6,'unpaid',10000,650000),(329075094,735481668,27,'personal',3,60000,8,'unpaid',56000,74400),(387380346,300807818,28,'car',2,54544,10,'unpaid',555,81816),(50394832,554152302,29,'car',2,96621,10,'unpaid',10000,144932),(646591845,854018808,30,'home',3,15460,6,'unpaid',1500,20098),(820909636,877153575,31,'car',4,599875,10,'unpaid',50000,899813),(82351033,485831677,32,'car',5,610000,10,'unpaid',50000,915000),(383376605,67126578,33,'personal',6,963000,8,'unpaid',60000,1194120),(78342298,712408567,34,'car',3,53099,10,'unpaid',20000,79649),(747865684,308680565,35,'car',1,756988,10,'unpaid',96000,1135482),(313654019,735481668,36,'car',5,1000000,10,'unpaid',900000,1500000),(541980591,300807818,37,'home',5,2558,6,'unpaid',100,3325),(658864353,554152302,38,'car',12,9633245,10,'unpaid',35442,14449868),(296560502,854018808,39,'personal',9,4844215,8,'unpaid',25963,6006827),(626771405,877153575,40,'car',8,484963,10,'unpaid',8500,727445),(306740510,485831677,41,'home',7,7895305,6,'unpaid',96358,10263897),(43008270,67126578,42,'car',6,6953,10,'unpaid',5000,10430),(663216313,712408567,43,'car',5,54899,10,'unpaid',5630,82349),(678864488,308680565,44,'personal',4,65000,8,'unpaid',2500,80600),(380183004,735481668,45,'personal',3,52000,8,'unpaid',50000,64480),(297458145,300807818,46,'home',2,36000,6,'unpaid',5069,46800),(896733792,554152302,47,'car',3,55000,10,'unpaid',55000,82500),(975613985,854018808,48,'personal',4,90000,8,'unpaid',10000,111600),(613814683,877153575,49,'personal',9,23000,8,'unpaid',23000,28520),(571041341,485831677,50,'home',10,89000,6,'unpaid',89000,115700),(721717683,308680565,52,'home',30,1,6,NULL,0,NULL);
/*!40000 ALTER TABLE `loan` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `loan_trigger` AFTER INSERT ON `loan` FOR EACH ROW BEGIN  
              IF (NEW.Amount_taken>1000000)
              THEN
              INSERT INTO loan_log  VALUES ( NEW.Loan_ID, NEW.CustomerID,NEW.Branch_ID,NEW.Amount_taken);
     END IF;
 END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `loan_status` AFTER INSERT ON `loan` FOR EACH ROW begin
		if(New.Amount_taken<=0)
        then
        delete from loan where loan_id=new.Loan_id;
	end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-29 13:53:32
