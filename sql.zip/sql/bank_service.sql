-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: bank
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service` (
  `CustomerID` int NOT NULL,
  `ID` int NOT NULL AUTO_INCREMENT,
  `Service_Type` varchar(80) NOT NULL,
  `DORQ` date NOT NULL,
  `DORS` date DEFAULT NULL,
  `Service_Status` varchar(80) NOT NULL,
  `Service_Description` varchar(1000) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `CustomerID` (`CustomerID`),
  CONSTRAINT `service_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customer` (`CustomerID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (354590595,1,'Passbook','2022-01-13','2022-01-16','not resolved','Need passbook'),(109329126,2,'Chequebook','2022-01-24','2022-01-25','not resolved','Need Chequebook'),(182330905,3,'Creditcard','2022-01-17','2022-01-21','not resolved','Need creditcard'),(938460904,4,'Recharge','2022-01-19','2022-01-29','resolved','Need recharge'),(105007482,5,'Recharge','2022-01-14','2022-01-24','not resolved','Need recharge'),(340862630,6,'Recharge','2021-11-10','2021-11-20','not resolved','Need recharge'),(256432348,7,'Chequebook','2022-01-25','2022-01-27','not resolved','Need Chequebook'),(126449721,8,'Chequebook','2022-01-19','2022-01-22','resolved','Need Chequebook'),(917381274,9,'Passbook','2021-12-15','2021-12-18','not resolved','Need passbook'),(401321729,10,'Creditcard','2021-11-11','2021-11-21','not resolved','Need creditcard'),(429198326,11,'Chequebook','2022-01-18','2022-01-28','resolved','Need Chequebook'),(613627569,12,'Creditcard','2021-12-03','2021-12-13','not resolved','Need creditcard'),(505518687,13,'Recharge','2021-12-10','2021-12-13','not resolved','Need recharge'),(964356938,14,'Recharge','2021-12-24','2021-12-26','not resolved','Need recharge'),(124312820,15,'Recharge','2021-12-02','2021-12-04','not resolved','Need recharge'),(692511833,16,'Creditcard','2021-11-26','2021-11-27','not resolved','Need creditcard'),(646591845,17,'Passbook','2022-01-04','2022-01-06','not resolved','Need passbook'),(82351033,18,'Creditcard','2021-11-23','2021-11-25','not resolved','Need creditcard'),(383376605,19,'Creditcard','2022-01-11','2022-01-14','not resolved','Need creditcard'),(78342298,20,'Creditcard','2022-01-20','2022-01-28','resolved','Need creditcard'),(747865684,21,'Chequebook','2021-12-10','2021-12-20','resolved','Need Chequebook'),(626771405,22,'Creditcard','2021-12-06','2021-12-07','not resolved','Need creditcard'),(306740510,23,'Recharge','2021-12-07','2021-12-08','not resolved','Need recharge'),(43008270,24,'Recharge','2021-12-15','2021-12-19','not resolved','Need recharge'),(663216313,25,'Recharge','2021-12-14','2021-12-15','resolved','Need recharge'),(678864488,26,'Creditcard','2022-01-13','2022-01-16','resolved','Need recharge'),(303601023,27,'Recharge','2021-11-26','2021-11-27','not resolved','Need recharge'),(296205659,28,'Recharge','2021-11-15','2021-11-17','resolved','Need recharge'),(722579690,29,'Chequebook','2022-01-13','2022-01-18','resolved','Need Chequebook'),(313638535,30,'Chequebook','2021-12-15','2021-12-19','resolved','Need Chequebook');
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-29 13:53:33
