-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: bank
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Account_No` char(11) NOT NULL,
  `Date_of_Transaction` date NOT NULL,
  `Type_of_Transaction` varchar(6) NOT NULL,
  `Amount` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Account_No` (`Account_No`),
  CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`Account_No`) REFERENCES `account_` (`Account_No`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (61,'31881661115','2020-10-28','Credit',10000),(62,'97361291420','2020-10-21','Debit',1000),(63,'81369428614','2021-08-13','Credit',500),(64,'5572403372','2019-08-30','Credit',600),(65,'46661679688','2020-03-05','Credit',700),(66,'69470445456','2021-03-16','Credit',900),(67,'92147571936','2020-05-20','Debit',3000),(68,'10532014694','2019-09-06','Debit',899),(69,'14123172323','2021-03-12','Debit',250),(70,'85062875464','2020-07-05','Credit',1),(71,'79837834518','2020-09-28','Credit',6300),(72,'89579399752','2020-04-25','Debit',850),(73,'46020871044','2021-01-11','Debit',520),(74,'47667824670','2020-02-06','Debit',963),(75,'27691271738','2020-04-27','Debit',456),(76,'74162454688','2021-01-18','Credit',7899),(77,'14615815945','2020-01-22','Credit',1200),(78,'18204043171','2021-01-27','Credit',500),(79,'96062978900','2020-07-31','Credit',5000),(80,'47667824670','2019-05-23','Credit',1200),(81,'27691271738','2020-04-19','Debit',1300),(82,'74162454688','2021-07-15','Debit',1400),(83,'14615815945','2019-07-27','Credit',1500),(84,'14615815945','2019-07-11','Debit',1600),(85,'14615815945','2020-08-22','Credit',1700),(86,'97361291420','2021-11-30','Credit',1800),(87,'81369428614','2019-05-31','Debit',1900),(88,'5572403372','2021-05-15','Credit',2000),(89,'46661679688','2021-01-24','Debit',6300),(90,'5572403372','2020-01-18','Debit',6300),(91,'31881661115','2022-03-25','Debit',100000),(92,'31881661115','2022-03-25','Debit',100000);
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `insert_after_employee_details` AFTER INSERT ON `transaction` FOR EACH ROW BEGIN  
              IF (NEW.Amount>10000)
              THEN
              INSERT INTO transaction_log ( AccountNo,Amount ) VALUES ( NEW.Account_No, NEW.amount);
     END IF;
 END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-29 13:53:34
